﻿using System;
using System.Windows;
using System.Windows.Media.Animation;
using System.Windows.Media.Media3D;

namespace Wpf3DApp
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            Loaded += MainWindow_Loaded;
        }

        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            var rotation = new AxisAngleRotation3D(new Vector3D(0, 1, 0), 0);
            var rotateTransform = new RotateTransform3D(rotation);

            var modelGroup = (Model3DGroup)((ModelVisual3D)viewport.Children[0]).Content;
            foreach (var model in modelGroup.Children)
            {
                model.Transform = rotateTransform;
                StartAnimation(rotation);
            }
        }

        private void StartAnimation(AxisAngleRotation3D rotation)
        {
            var animation = new DoubleAnimation
            {
                From = 0,
                To = 360,
                Duration = new Duration(TimeSpan.FromSeconds(10)),
                RepeatBehavior = RepeatBehavior.Forever
            };
            rotation.BeginAnimation(AxisAngleRotation3D.AngleProperty, animation);
        }
    }
}
